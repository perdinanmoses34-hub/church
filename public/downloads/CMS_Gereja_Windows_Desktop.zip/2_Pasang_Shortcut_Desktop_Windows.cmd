@echo off
title Pasang Shortcut CMS Gereja Desktop
cls
echo ======================================================================
echo          PEMASANGAN SHORTCUT DESKTOP WINDOWS - CMS GEREJA
echo ======================================================================
echo.
echo Sedang membuat shortcut di Layar Desktop Windows...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  " = [System.IO.Path]::Combine([System.Environment]::GetFolderPath('Desktop'), 'CMS Gereja Desktop.lnk');" ^
  " = New-Object -ComObject WScript.Shell;" ^
  " = .CreateShortcut();" ^
  ".TargetPath = 'msedge.exe';" ^
  ".Arguments = '--app=https://perdinanmoses34-hub.github.io/church/ --start-maximized';" ^
  ".Description = 'Aplikasi Sistem Informasi Gereja - Monapa Puriala';" ^
  ".Save();" ^
  "Write-Host 'Shortcut berhasil dibuat di Desktop Anda!' -ForegroundColor Green;"

echo.
echo ======================================================================
echo  SUKSES! Icon 'CMS Gereja Desktop' telah terpasang di Layar Desktop.
echo  Klik ganda icon tersebut kapan saja untuk membuka aplikasi langsung!
echo ======================================================================
echo.
pause
exit
