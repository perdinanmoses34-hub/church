@echo off
title CMS Gereja Windows Desktop
cls
echo ======================================================================
echo           APLIKASI SISTEM INFORMASI MANAJEMEN GEREJA (CMS PRO)
echo                        VERSI DESKTOP WINDOWS
echo ======================================================================
echo.
echo Sedang membuka aplikasi dalam mode layar penuh (Native Desktop Window)...
echo.

start msedge --app="https://perdinanmoses34-hub.github.io/church/" --start-maximized --window-size=1366,768
if %errorlevel% equ 0 goto selesai

start chrome --app="https://perdinanmoses34-hub.github.io/church/" --start-maximized --window-size=1366,768
if %errorlevel% equ 0 goto selesai

start "" "https://perdinanmoses34-hub.github.io/church/"

:selesai
exit
